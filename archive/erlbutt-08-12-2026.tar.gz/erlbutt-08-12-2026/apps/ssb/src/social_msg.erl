%% SPDX-License-Identifier: GPL-2.0-only
%%
%% Copyright (C) 2023 Charles Moid
%%
%% Message-type predicates, and the dispatch of a stored message to the
%% handlers that care about its type.
%%
%% This module straddles the foundation/convention line (doc/persistence.md
%% §5), and the split runs *through* it rather than around it:
%%
%%   FOUNDATION — stays here.  `contact` and `about` are de-facto
%%     protocol: ebt cannot replicate without the follow graph, so
%%     is_follow/1, is_block/1 and is_about/1 are what the core views
%%     ssb_social_graph and ssb_feed_meta fold.  dispatch/1 likewise —
%%     it registers pubs with conn_db and hands blob refs to the
%%     fetcher, both protocol concerns.
%%
%%   CONVENTION — gone.  is_branch/1 read `root`/`branch`, which only a
%%     conversation cares about; it lived here only because
%%     utils:update_refs/1 called it from the foundation to build the
%%     per-feed references file.  That file is now the ssb_links core
%%     view, which extracts references by shape and knows no message type
%%     at all, so is_branch/1 moved to ssb_conv_msg where it belongs.
%%
%% is_reply/1 and is_private_box/1 are convention predicates with no
%% caller anywhere — dead surface, not moved rather than moving dead code
%% into a new app.
-module(social_msg).
-include_lib("ssb/include/ssb.hrl").

-ifdef(TEST).
-include_lib("eunit/include/eunit.hrl").
-endif.

-import(message, [decode/2]).

%% API
-export([dispatch/1,
         is_follow/1,
         is_block/1,
         is_about/1,
         is_reply/1,
         is_private_box/1]).

%% Dispatch a stored message to application-layer handlers based on type.
dispatch(#message{author = Author, content = {Props}}) ->
    %% any blob referenced by the message gets requested from peers
    blob_fetcher:want_refs({Props}),
    Type = ?pgv(~"type", Props),
    dispatch_type(Type, Author, Props);
%% Private (encrypted) messages addressed to us: the content is a ".box"
%% string, so the clause above can't see inside it. Decrypt with our key and,
%% if it is for us, request any blob the sender attached (e.g. an image in a
%% DM). We only extract blob refs here — we do not run dispatch_type on
%% private content.
dispatch(#message{content = Content}) when is_binary(Content) ->
    case private_box:decrypt(Content) of
        {ok, Plain} ->
            %% Decrypted content is normally a JSON object, but a DM body can be
            %% any plaintext — nat_decode throws on non-JSON, so guard it.
            try utils:nat_decode(Plain) of
                {Props} -> blob_fetcher:want_refs({Props});
                _       -> ok
            catch _:_ -> ok
            end;
        _ ->
            ok
    end;
dispatch(_) ->
    ok.

dispatch_type(~"pub", _Author, Props) ->
    %% `address` is a nested JSON object, so it decodes to the {PropList}
    %% wrapper.  The is_list/1 guard is what makes the nested ?pgv calls
    %% safe: a malformed `{"address": {...}}` whose payload is not a
    %% proplist would otherwise reach proplists:get_value/2 and crash.
    case ?pgv(~"address", Props) of
        {AddrProps} when is_list(AddrProps) ->
            remember_pub(?pgv(~"host", AddrProps),
                         ?pgv(~"port", AddrProps),
                         ?pgv(~"key",  AddrProps));
        _ -> ok
    end;

%% contact and about messages are folded into the social graph view by
%% view_manager:ingest/1 (see ssb_social_graph:view_entry/1), not dispatched here.
dispatch_type(_, _, _) ->
    ok.

%% Guards in the head rather than a combined is_binary/is_integer test in the
%% body: same check, but it narrows Host/Port/Key from term() for the caller's
%% benefit and for eqwalize.
remember_pub(Host, Port, Key)
  when is_binary(Host), is_integer(Port), is_binary(Key) ->
    KeyBody = case Key of
                  <<"@", Rest/binary>> -> Rest;
                  Rest                 -> Rest
              end,
    KeyB64 = utils:strip_suffix(KeyBody, ~".ed25519"),
    Addr = iolist_to_binary([~"net:", Host, ~":",
                             integer_to_binary(Port),
                             ~"~shs:", KeyB64]),
    Meta = #{~"host" => Host, ~"port" => Port,
             ~"key"  => Key,  ~"type" => ~"pub"},
    conn_db:remember(Addr, Meta, ~"pub");
remember_pub(_Host, _Port, _Key) ->
    ok.

is_follow(#message{content = Val}) when is_binary(Val) ->
    nope;

is_follow(#message{content = {ContentProps}}) ->
    Type = ?pgv(~"type", ContentProps),
    case Type of
        ~"contact" ->
            check_contact(?pgv(~"contact",ContentProps),
                          ?pgv(~"following", ContentProps));
        _Else ->
            nope
    end.

is_block(#message{content = Val}) when is_binary(Val) ->
    nope;

is_block(#message{content = {ContentProps}}) ->
    case ?pgv(~"type", ContentProps) of
        ~"contact" ->
            check_block(?pgv(~"contact",  ContentProps),
                        ?pgv(~"blocking", ContentProps));
        _Else ->
            nope
    end.

is_about(#message{content = Content}) when is_binary(Content) ->
    false;

is_about(#message{content = {ContentProps}}) ->
    Type = ?pgv(~"type", ContentProps),
    case Type of
        undefined ->
            false;
        Type ->
            Type == ~"about"
    end.

is_reply(#message{content = Content}) when is_binary(Content) ->
    false;

is_reply(#message{content = {Content}}) ->
    build_reply(?pgv(~"reply", Content)).

build_reply(undefined) ->
    false;

build_reply(Reply) ->
    Reply.

is_private_box(#message{content = Content}) ->
    private_box:is_private(Content).

check_contact(undefined, _Following) ->
    nope;
check_contact(<<>>, _Following) ->
    nope;
check_contact(Contact, true) ->
    {Contact, true};
check_contact(Contact, false) ->
    {Contact, false};
check_contact(_Contact, _Following) ->
    nope.

check_block(undefined, _Blocking) ->
    nope;
check_block(<<>>, _Blocking) ->
    nope;
check_block(Contact, true) ->
    {Contact, true};
check_block(Contact, false) ->
    {Contact, false};
check_block(_Contact, _Blocking) ->
    nope.


-ifdef(TEST).


dispatch_pub_test() ->
    ConfigStarted = case whereis(config) of
        undefined -> {ok, _} = config:start_link("test/ssb.cfg"), true;
        _         -> false
    end,
    {ok, DbPid} = conn_db:start_link(),
    Msg = #message{id = ~"%test.sha256", previous = null,
                   author = ~"@author=.ed25519", sequence = 1,
                   timestamp = 0, hash = ~"sha256", received = 0,
                   validated = true, swapped = false, signature = ~"sig",
                   content = {[{~"type",    ~"pub"},
                                {~"address", {[{~"host", ~"pub.example.com"},
                                               {~"port", 8008},
                                               {~"key",  ~"@pubkey=.ed25519"}]}}]}},
    ok = social_msg:dispatch(Msg),
    All = conn_db:all(),
    ExpAddr = ~"net:pub.example.com:8008~shs:pubkey=",
    ?assert(maps:is_key(ExpAddr, All)),
    gen_server:stop(DbPid),
    file:delete(?b2l(config:ssb_repo_loc()) ++ "conn.json"),
    case ConfigStarted of
        true -> gen_server:stop(config);
        false -> ok
    end.

%% A `pub` whose address object is not a proplist must be ignored, not crash
%% the dispatch: the payload comes off the wire, so its shape is not ours to
%% trust.  Nothing runs here (conn_db is not started) — reaching it would
%% already have thrown from proplists:get_value/2.
dispatch_pub_malformed_address_test() ->
    Mk = fun(Addr) ->
        #message{id = ~"%bad.sha256", previous = null,
                 author = ~"@author=.ed25519", sequence = 1,
                 timestamp = 0, hash = ~"sha256", received = 0,
                 validated = true, swapped = false, signature = ~"sig",
                 content = {[{~"type", ~"pub"}, {~"address", Addr}]}}
    end,
    %% {Term} wrapper present but payload is not a proplist
    ?assertEqual(ok, social_msg:dispatch(Mk({~"net:host:8008"}))),
    ?assertEqual(ok, social_msg:dispatch(Mk({42}))),
    %% no wrapper at all: legacy string form, and outright missing
    ?assertEqual(ok, social_msg:dispatch(Mk(~"net:host:8008~shs:k="))),
    ?assertEqual(ok, social_msg:dispatch(
                       #message{id = ~"%none.sha256", previous = null,
                                author = ~"@author=.ed25519", sequence = 1,
                                timestamp = 0, hash = ~"sha256", received = 0,
                                validated = true, swapped = false,
                                signature = ~"sig",
                                content = {[{~"type", ~"pub"}]}})).

dispatch_contact_test() ->
    Msg = #message{id = ~"%c.sha256", previous = null,
                   author = ~"@author=.ed25519", sequence = 2,
                   timestamp = 0, hash = ~"sha256", received = 0,
                   validated = true, swapped = false, signature = ~"sig",
                   content = {[{~"type",      ~"contact"},
                                {~"contact",   ~"@other=.ed25519"},
                                {~"following", true}]}},
    ?assertEqual(ok, social_msg:dispatch(Msg)).

%% Without the social graph server running, dispatch must still succeed.
dispatch_about_no_friends_test() ->
    Msg = #message{id = ~"%a3.sha256", previous = null,
                   author = ~"@author=.ed25519", sequence = 5,
                   timestamp = 0, hash = ~"sha256", received = 0,
                   validated = true, swapped = false, signature = ~"sig",
                   content = {[{~"type",  ~"about"},
                                {~"about", ~"@author=.ed25519"},
                                {~"name",  ~"zelda"}]}},
    ?assertEqual(ok, social_msg:dispatch(Msg)).

dispatch_unknown_type_test() ->
    Msg = #message{id = ~"%p.sha256", previous = null,
                   author = ~"@author=.ed25519", sequence = 3,
                   timestamp = 0, hash = ~"sha256", received = 0,
                   validated = true, swapped = false, signature = ~"sig",
                   content = {[{~"type", ~"post"}, {~"text", ~"hello"}]}},
    ?assertEqual(ok, social_msg:dispatch(Msg)).

%% A post with a blob mention must dispatch fine without blob_fetcher running.
dispatch_blob_mention_no_fetcher_test() ->
    BlobId = <<"&", (base64:encode(crypto:hash(sha256, ~"pic")))/binary, ".sha256">>,
    Msg = #message{id = ~"%m.sha256", previous = null,
                   author = ~"@author=.ed25519", sequence = 6,
                   timestamp = 0, hash = ~"sha256", received = 0,
                   validated = true, swapped = false, signature = ~"sig",
                   content = {[{~"type", ~"post"}, {~"text", ~"see pic"},
                                {~"mentions", [{[{~"link", BlobId}]}]}]}},
    ?assertEqual(ok, social_msg:dispatch(Msg)).

dispatch_private_test() ->
    Msg = #message{id = ~"%priv.sha256", previous = null,
                   author = ~"@author=.ed25519", sequence = 4,
                   timestamp = 0, hash = ~"sha256", received = 0,
                   validated = true, swapped = false, signature = ~"sig",
                   content = ~"box.encrypted"},
    ?assertEqual(ok, social_msg:dispatch(Msg)).

is_about_test() ->
    {ok, Cwd} = file:get_cwd(),
    F = Cwd ++ "/testdata/" ++ "about.full",
    {ok, FilBin} = file:read_file(F),

    ?assert(social_msg:is_about(decode(FilBin, true))).

is_reply_test() ->
    {ok, Cwd} = file:get_cwd(),
    F = Cwd ++ "/testdata/" ++ "reply.full",
    {ok, FilBin} = file:read_file(F),

    ?assert(social_msg:is_reply(decode(FilBin, true)) /= false).

is_multi_reply_test() ->
    {ok, Cwd} = file:get_cwd(),
    F = Cwd ++ "/testdata/" ++ "mult-reply.full",
    {ok, FilBin} = file:read_file(F),
    Msg = decode(FilBin, true),
    {ListPairs} = social_msg:is_reply(Msg),
    ?assert(length(ListPairs) == 2).

is_not_reply_test() ->
    {ok, Cwd} = file:get_cwd(),
    F = Cwd ++ "/testdata/" ++ "not_reply.full",
    {ok, FilBin} = file:read_file(F),

    ?assert(not social_msg:is_reply(decode(FilBin, true))).

follow_true_test() ->
    {ok, Cwd} = file:get_cwd(),
    F = Cwd ++ "/testdata/" ++ "follow_true.full",
    {ok, FilBin} = file:read_file(F),
    {_FeedId, Bool} = social_msg:is_follow(decode(FilBin, true)),

    ?assert(Bool).

follow_false_test() ->
    {ok, Cwd} = file:get_cwd(),
    F = Cwd ++ "/testdata/" ++ "follow_false.full",
    {ok, FilBin} = file:read_file(F),
    {_FeedId, Bool} = social_msg:is_follow(decode(FilBin, true)),

    ?assert(not Bool).

-endif.
